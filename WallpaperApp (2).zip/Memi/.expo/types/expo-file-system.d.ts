// import * as FileSystem from 'expo-file-system';

// // Explicitly declare the types
// const { documentDirectory }: { documentDirectory: string } = FileSystem;

// export const downloadFile = async () => {
//   const fileUri = documentDirectory + 'myFile.txt';
//   try {
//     const downloadResult = await FileSystem.downloadAsync(
//       'https://example.com/myFile.txt',
//       fileUri
//     );
//     console.log('Finished downloading to ', downloadResult.uri);
//   } catch (error) {
//     console.error('Error downloading file:', error);
//   }
// };
