/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/AppNavigator` | `/_sitemap` | `/screens/FavoritesScreen` | `/screens/HomeScreen` | `/screens/OnboardingScreen` | `/screens/SplashScreen` | `/screens/UsePexels` | `/screens/WallpaperItem`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
