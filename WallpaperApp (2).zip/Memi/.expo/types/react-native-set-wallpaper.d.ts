declare module 'react-native-set-wallpaper' {
  export default class SetWallpaper {
    static setWallpaper(options: { uri: string }): Promise<void>;
  }
}